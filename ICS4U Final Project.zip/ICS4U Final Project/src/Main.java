import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 @author Ben Newman
 Title: Main
 Date: June 12, 2024,
 Description: Main class to set up the Checkers game menu
 */
public class Main {
    JFrame frame; // Main frame for the application
    JPanel contentPane; // Main content pane
    JLabel label; // Label for the title
    JButton playButton, statsButton, controlsButton, rulesButton, quitButton; // Buttons for different actions

    /**
     * Constructor to set up the frame and its components
     */
    public Main() {
        frame = new JFrame("Checkers Game"); // Create a new frame with title
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Set default close operation

        contentPane = new JPanel(); // Create a new panel for content
        contentPane.setPreferredSize(new Dimension(640, 640)); // Set preferred size
        contentPane.setLayout(null); // Use null layout for absolute positioning
        Insets insets = contentPane.getInsets(); // Get insets for padding

        // Set up the title label
        label = new JLabel("Checkers");
        label.setFont(new Font("Verdana", Font.PLAIN, 40));
        Dimension labelSize = label.getPreferredSize();
        label.setBounds(insets.left + 320 - labelSize.width / 2, insets.top + 150, labelSize.width, labelSize.height);
        contentPane.add(label); // Add label to content pane

        // Set up the play button
        playButton = new JButton("                    Play                    ");
        playButton.setFont(new Font("Verdana", Font.PLAIN, 20));
        Dimension playSize = playButton.getPreferredSize();
        playButton.setBounds(insets.left + 320 - playSize.width / 2, insets.top + 230, playSize.width, playSize.height);
        playButton.addActionListener(new PlayListener()); // Add action listener
        contentPane.add(playButton, BorderLayout.CENTER); // Add button to content pane

        // Set up the stats button
        statsButton = new JButton("                   Stats                   ");
        statsButton.setFont(new Font("Verdana", Font.PLAIN, 20));
        Dimension statSize = statsButton.getPreferredSize();
        statsButton.setBounds(insets.left + 320 - statSize.width / 2, insets.top + 270, statSize.width, statSize.height);
        statsButton.addActionListener(new StatListener()); // Add action listener
        contentPane.add(statsButton, BorderLayout.CENTER); // Add button to content pane

        // Set up the controls button
        controlsButton = new JButton("                 Controls                 ");
        controlsButton.setFont(new Font("Verdana", Font.PLAIN, 20));
        Dimension controlSize = controlsButton.getPreferredSize();
        controlsButton.setBounds(insets.left + 320 - controlSize.width / 2, insets.top + 310, controlSize.width, controlSize.height);
        controlsButton.addActionListener(new ControlListener()); // Add action listener
        contentPane.add(controlsButton, BorderLayout.CENTER); // Add button to content pane

        // Set up the rules button
        rulesButton = new JButton("                   Rules                   ");
        rulesButton.setFont(new Font("Verdana", Font.PLAIN, 20));
        Dimension ruleSize = rulesButton.getPreferredSize();
        rulesButton.setBounds(insets.left + 320 - ruleSize.width / 2, insets.top + 350, ruleSize.width, ruleSize.height);
        rulesButton.addActionListener(new RuleListener()); // Add action listener
        contentPane.add(rulesButton, BorderLayout.CENTER); // Add button to content pane

        // Set up the quit button
        quitButton = new JButton("                    Quit                    ");
        quitButton.setFont(new Font("Verdana", Font.PLAIN, 20));
        Dimension quitSize = quitButton.getPreferredSize();
        quitButton.setBounds(insets.left + 320 - quitSize.width / 2, insets.top + 390, quitSize.width, quitSize.height);
        quitButton.addActionListener(new QuitListener()); // Add action listener
        contentPane.add(quitButton, BorderLayout.CENTER); // Add button to content pane

        // Add content pane to frame
        frame.setContentPane(contentPane);

        // Size and then display the frame
        frame.pack();
        frame.setVisible(true);
    }

    // ActionListener for the Play button
    class PlayListener implements ActionListener {
        public void actionPerformed(ActionEvent event) {
            Board board = new Board(frame); // Create a new Board instance
            frame.setContentPane(board); // Set the frame's content pane to the board
            frame.pack(); // Pack the frame
            frame.setVisible(true); // Make the frame visible
        }
    }

    // ActionListener for the Stats button
    class StatListener implements ActionListener {
        public void actionPerformed(ActionEvent event) {
            try {
                BufferedReader reader = new BufferedReader(new FileReader("stats.txt")); // Read stats from file
                String whiteWins = reader.readLine();
                String blackWins = reader.readLine();
                JOptionPane.showMessageDialog(contentPane, "White wins: " + whiteWins + "\nBlack wins: " + blackWins); // Show stats in a message dialog
            } catch (IOException e) {
                throw new RuntimeException(e); // Handle exceptions
            }
        }
    }

    // ActionListener for the Controls button
    class ControlListener implements ActionListener {
        public void actionPerformed(ActionEvent event) {
            JOptionPane.showMessageDialog(contentPane, "Click the piece that you want to move, then\nclick the square that you want to move it to."); // Show controls in a message dialog
        }
    }

    // ActionListener for the Rules button
    class RuleListener implements ActionListener {
        public void actionPerformed(ActionEvent event) {
            JOptionPane.showMessageDialog(contentPane, "1. Uncrowned pieces may only move forwards and diagonally\n2. To capture a piece, jump diagonally over your opponent's piece\n(only if there is an empty space to jump to)\n3. If your piece makes it to the final row, it is 'crowned'\nand can move backwards or forwards diagonally\n4. Game ends when one player has no pieces remaining or no valid moves"); // Show rules in a message dialog
        }
    }

    // ActionListener for the Quit button
    class QuitListener implements ActionListener {
        public void actionPerformed(ActionEvent event) {
            System.exit(0); // Exit the application
        }
    }

    // Method to run the GUI
    public static void runGUI() {
        JFrame.setDefaultLookAndFeelDecorated(true); // Set default look and feel
        new Main(); // Run Main
    }

    // Main method to start the application
    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                runGUI(); // Run the GUI
            }
        });
    }
}
/*
Algorithm:

Class Main:
    Variables:
        JFrame frame
        JPanel contentPane
        JLabel label
        JButton playButton, statsButton, controlsButton, rulesButton, quitButton

    Constructor Main():
        Initialize the frame with title "Checkers Game"
        Set the default close operation of the frame to EXIT_ON_CLOSE

        Initialize contentPane as a new JPanel
        Set preferred size of contentPane to (640, 640)
        Set layout of contentPane to null
        Get insets from contentPane

        Initialize label as a new JLabel with text "Checkers"
        Set label font to Verdana, size 40
        Get preferred size of label
        Set bounds of label to center it horizontally and position it at a fixed vertical position
        Add label to contentPane

        Initialize playButton as a new JButton with text "Play"
        Set playButton font to Verdana, size 20
        Get preferred size of playButton
        Set bounds of playButton to center it horizontally and position it below the label
        Add an ActionListener (PlayListener) to playButton
        Add playButton to contentPane

        Initialize statsButton as a new JButton with text "Stats"
        Set statsButton font to Verdana, size 20
        Get preferred size of statsButton
        Set bounds of statsButton to center it horizontally and position it below the playButton
        Add an ActionListener (StatListener) to statsButton
        Add statsButton to contentPane

        Initialize controlsButton as a new JButton with text "Controls"
        Set controlsButton font to Verdana, size 20
        Get preferred size of controlsButton
        Set bounds of controlsButton to center it horizontally and position it below the statsButton
        Add an ActionListener (ControlListener) to controlsButton
        Add controlsButton to contentPane

        Initialize rulesButton as a new JButton with text "Rules"
        Set rulesButton font to Verdana, size 20
        Get preferred size of rulesButton
        Set bounds of rulesButton to center it horizontally and position it below the controlsButton
        Add an ActionListener (RuleListener) to rulesButton
        Add rulesButton to contentPane

        Initialize quitButton as a new JButton with text "Quit"
        Set quitButton font to Verdana, size 20
        Get preferred size of quitButton
        Set bounds of quitButton to center it horizontally and position it below the rulesButton
        Add an ActionListener (QuitListener) to quitButton
        Add quitButton to contentPane

        Add contentPane to frame
        Pack the frame
        Make the frame visible

    Inner Class PlayListener implements ActionListener:
        Method actionPerformed(ActionEvent event):
            Create a new Board instance with frame
            Set frame content pane to the new Board instance
            Pack the frame
            Make the frame visible

    Inner Class StatListener implements ActionListener:
        Method actionPerformed(ActionEvent event):
            Try:
                Open stats file for reading
                Read whiteWins and blackWins from the file
                Display a message dialog with the stats
            Catch IOException:
                Throw a RuntimeException with the caught exception

    Inner Class ControlListener implements ActionListener:
        Method actionPerformed(ActionEvent event):
            Display a message dialog with game controls

    Inner Class RuleListener implements ActionListener:
        Method actionPerformed(ActionEvent event):
            Display a message dialog with game rules

    Inner Class QuitListener implements ActionListener:
        Method actionPerformed(ActionEvent event):
            Exit the application

    Static Method runGUI():
        Set default look and feel decorated for JFrame
        Create a new instance of Main

    Public Static Method main(String[] args):
        Invoke the runGUI method on the event dispatch thread

 */