/**
 @author Ben Newman
 Title: Piece
 Date: June 12, 2024,
 Description: Piece class to represent a checkers piece
 */
public class Piece {
    private PieceType type; // Type of the piece (BLACK or WHITE)
    private boolean isKing; // Flag to indicate if the piece is a king

    // Constructor to initialize the piece with its type
    public Piece(PieceType type) {
        this.type = type; // Set the type of the piece
        this.isKing = false; // Initially, the piece is not a king
    }

    // Getter method to return the type of the piece
    public PieceType getType() {
        return type;
    }

    // Getter method to check if the piece is a king
    public boolean isKing() {
        return isKing;
    }

    // Setter method to set the piece as a king
    public void setKing(boolean isKing) {
        this.isKing = isKing;
    }
}
/*
Algorithm:

Class Piece:
    Variables:
        PieceType type
        boolean isKing

    Constructor Piece(PieceType type):
        Set the instance variable type to the provided type
        Set the instance variable isKing to false

    Method getType() returns PieceType:
        Return the type of the piece

    Method isKing() returns boolean:
        Return the isKing status of the piece

    Method setKing(boolean isKing):
        Set the isKing status of the piece to the provided value

 */