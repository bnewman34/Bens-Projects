import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;

/**
 @author Ben Newman
 Title: Board
 Date: June 12, 2024,
 Description: extends JPanel and implements ActionListener to create and update the checkers board
 */
public class Board extends JPanel implements ActionListener {
    private final int BOARD_SIZE = 8; // Constant for board size
    private final JButton[][] squares = new JButton[BOARD_SIZE][BOARD_SIZE]; // 2D array of buttons representing the board
    private Piece[][] board = new Piece[BOARD_SIZE][BOARD_SIZE]; // 2D array of pieces on the board
    private int selectedRow = -1, selectedCol = -1; // Variables to track selected piece position
    private PieceType currentPlayer = PieceType.BLACK; // Variable to track current player
    private boolean mustContinueCapture = false; // Flag to check if a piece must continue capturing
    private JFrame frame; // Reference to the frame containing the board
    private final Color light = Color.WHITE; // Light color for the board
    private final Color dark = Color.DARK_GRAY; // Dark color for the board
    private final Color highlight = Color.YELLOW; // Highlight color for selected piece

    /**
     * Constructor that initializes the board and sets up the GUI
     * @param frame the JFrame that the Board panel is added to
     */
    public Board(JFrame frame) {
        this.frame = frame;
        setLayout(new GridLayout(BOARD_SIZE, BOARD_SIZE)); // Set layout to grid
        initializeBoard(); // Initialize board buttons
        setupBoard(); // Set up initial pieces on the board
        updateTitle(); // Update the title to show the current player's turn
    }

    /**
     * Method to initialize board buttons
     */
    private void initializeBoard() {
        for (int row = 0; row < BOARD_SIZE; row++) {
            for (int col = 0; col < BOARD_SIZE; col++) {
                JButton button = new JButton(); // Create new button
                button.setPreferredSize(new Dimension(80, 80)); // Set button size
                button.addActionListener(this); // Add action listener to button
                button.setBorderPainted(false); // Remove button border
                button.setOpaque(true); // Make button opaque
                button.setBackground((row + col) % 2 == 0 ? light : dark); // Set button background color
                squares[row][col] = button; // Store button in array
                add(button); // Add button to panel
            }
        }
    }

    /**
     * Method to set up initial pieces on the board
     */
    private void setupBoard() {
        // Place black pieces
        for (int row = 0; row < 3; row++) {
            for (int col = (row % 2 == 0) ? 1 : 0; col < BOARD_SIZE; col += 2) {
                board[row][col] = new Piece(PieceType.BLACK);
            }
        }

        // Place white pieces
        for (int row = 5; row < 8; row++) {
            for (int col = (row % 2 == 0) ? 1 : 0; col < BOARD_SIZE; col += 2) {
                board[row][col] = new Piece(PieceType.WHITE);
            }
        }

        refreshBoard(); // Refresh board to show initial pieces
    }

    /**
     * Method to refresh the board display
     */
    private void refreshBoard() {
        for (int row = 0; row < BOARD_SIZE; row++) {
            for (int col = 0; col < BOARD_SIZE; col++) {
                if (board[row][col] == null) {
                    squares[row][col].setIcon(null); // Clear button icon if no piece
                } else {
                    String iconPath = "";
                    if (board[row][col].getType() == PieceType.BLACK) {
                        iconPath = board[row][col].isKing() ? "black_king.png" : "black_piece.png"; // Set icon path for black piece
                    } else {
                        iconPath = board[row][col].isKing() ? "white_king.png" : "white_piece.png"; // Set icon path for white piece
                    }
                    squares[row][col].setIcon(new ImageIcon(new ImageIcon(iconPath).getImage().getScaledInstance(60, 60, Image.SCALE_SMOOTH))); // Set button icon
                }
                squares[row][col].setBackground((row + col) % 2 == 0 ? light : dark); // Reset button background color
            }
        }
    }

    /**
     * Method to handle button click events
     * @param e the event to be processed
     */
    public void actionPerformed(ActionEvent e) {
        JButton button = (JButton) e.getSource(); // Get the source button of the event
        for (int row = 0; row < BOARD_SIZE; row++) {
            for (int col = 0; col < BOARD_SIZE; col++) {
                if (squares[row][col] == button) {
                    try {
                        handleMove(row, col); // Handle the move for the clicked button
                    } catch (IOException ex) {
                        throw new RuntimeException(ex);
                    }
                    return;
                }
            }
        }
    }

    /**
     * Method to handle piece movement
     * @param row row of the selected piece
     * @param col column of the selected piece
     */
    private void handleMove(int row, int col) throws IOException {
        if (selectedRow == -1) { // If no piece is selected
            if (board[row][col] != null && board[row][col].getType() == currentPlayer) { // Check if the selected piece belongs to the current player
                selectedRow = row;
                selectedCol = col;
                squares[row][col].setBackground(highlight); // Highlight the selected piece
            }
        } else { // If a piece is already selected
            if (isValidMove(selectedRow, selectedCol, row, col)) { // Check if the move is valid
                movePiece(selectedRow, selectedCol, row, col); // Move the piece
                if (Math.abs(selectedRow - row) == 2) { // If the move is a capture
                    int capturedRow = (selectedRow + row) / 2;
                    int capturedCol = (selectedCol + col) / 2;
                    board[capturedRow][capturedCol] = null; // Remove the captured piece
                }
                crownPiece(row, col); // Check if the piece should be crowned
                refreshBoard(); // Refresh the board display

                if (Math.abs(selectedRow - row) == 2 && canCaptureMore(row, col)) { // Check if the piece can capture more
                    selectedRow = row;
                    selectedCol = col;
                    squares[selectedRow][selectedCol].setBackground(highlight); // Highlight the piece for further capture
                    mustContinueCapture = true;
                    return;
                }

                mustContinueCapture = false;
                checkForWin(); // Check for win condition
                currentPlayer = (currentPlayer == PieceType.BLACK) ? PieceType.WHITE : PieceType.BLACK; // Switch player turn
                updateTitle(); // Update the title to show the current player's turn
            }
            if (!mustContinueCapture) { // If the piece does not need to continue capturing
                squares[selectedRow][selectedCol].setBackground((selectedRow + selectedCol) % 2 == 0 ? light : dark); // Reset the background color of the previously selected piece
                selectedRow = -1;
                selectedCol = -1; // Reset the selected piece
            }
        }
    }

    /**
     * Method to move a piece from one position to another
     * @param fromRow the row the piece is moving from
     * @param fromCol the column the piece is moving from
     * @param toRow the row that the piece is moving to
     * @param toCol the column that the piece is moving to
     */
    private void movePiece(int fromRow, int fromCol, int toRow, int toCol) {
        board[toRow][toCol] = board[fromRow][fromCol]; // Move the piece
        board[fromRow][fromCol] = null; // Clear the original position
    }

    /**
     * Method to crown a piece if it reaches the opposite end
     * @param row the row of the piece
     * @param col the column of the piece
     */
    private void crownPiece(int row, int col) {
        if (row == 0 && board[row][col].getType() == PieceType.WHITE) {
            board[row][col].setKing(true); // Crown the white piece
        } else if (row == 7 && board[row][col].getType() == PieceType.BLACK) {
            board[row][col].setKing(true); // Crown the black piece
        }
    }

    /**
     * Method to check if a move is valid
     * @param fromRow the row that the piece is moving from
     * @param fromCol the column that the piece is moving from
     * @param toRow the row that the piece is moving to
     * @param toCol the column that the piece is moving to
     * @return true if the move is legal by the rules of checkers and false if not
     */
    private boolean isValidMove(int fromRow, int fromCol, int toRow, int toCol) {
        Piece piece = board[fromRow][fromCol]; // Get the piece to move
        if (piece == null || board[toRow][toCol] != null) { // Check if the move is invalid
            return false;
        }

        int rowDiff = toRow - fromRow;
        int colDiff = Math.abs(toCol - fromCol);

        if (piece.isKing()) { // If the piece is a king
            if (Math.abs(rowDiff) != 1 && Math.abs(rowDiff) != 2) return false; // Check row difference
            if (Math.abs(rowDiff) == 1 && colDiff != 1) return false; // Check column difference for simple move
            if (Math.abs(rowDiff) == 2 && colDiff != 2) return false; // Check column difference for capture move
        } else {
            if (piece.getType() == PieceType.BLACK) { // If the piece is a black piece
                if (rowDiff != 1 && rowDiff != 2) return false; // Check row difference for black piece
                if (rowDiff == 1 && colDiff != 1) return false; // Check column difference for simple move
                if (rowDiff == 2 && colDiff != 2) return false; // Check column difference for capture move
            } else if (piece.getType() == PieceType.WHITE) { // If the piece is a white piece
                if (rowDiff != -1 && rowDiff != -2) return false; // Check row difference for white piece
                if (rowDiff == -1 && colDiff != 1) return false; // Check column difference for simple move
                if (rowDiff == -2 && colDiff != 2) return false; // Check column difference for capture move
            }
        }

        if (Math.abs(rowDiff) == 2) { // If the move is a capture move
            int capturedRow = (fromRow + toRow) / 2;
            int capturedCol = (fromCol + toCol) / 2;
            if (board[capturedRow][capturedCol] == null || board[capturedRow][capturedCol].getType() == piece.getType()) {
                return false; // Check if the captured piece is valid
            }
        }

        return true; // The move is valid
    }

    /**
     * Method to check if a piece can capture more
     * @param row the row that the piece is in
     * @param col the column that the piece is in
     * @return true if the piece is able to capture another piece in the same turn
     */
    private boolean canCaptureMore(int row, int col) {
        Piece piece = board[row][col]; // Get the piece to check
        if (piece == null) {
            return false;
        }

        int[] dRows = {-2, 2, -2, 2}; // Possible row differences for capture
        int[] dCols = {-2, -2, 2, 2}; // Possible column differences for capture

        for (int i = 0; i < 4; i++) {
            int newRow = row + dRows[i];
            int newCol = col + dCols[i];
            if (newRow >= 0 && newRow < BOARD_SIZE && newCol >= 0 && newCol < BOARD_SIZE) { // Check if the move is within bounds
                if (isValidMove(row, col, newRow, newCol)) {
                    return true; // The piece can capture more
                }
            }
        }
        return false; // The piece cannot capture more
    }

    /**
     * Method to check for win conditions
     */
    private void checkForWin() throws IOException {
        boolean blackExists = false;
        boolean whiteExists = false;
        boolean blackCanMove = false;
        boolean whiteCanMove = false;

        for (int row = 0; row < BOARD_SIZE; row++) {
            for (int col = 0; col < BOARD_SIZE; col++) {
                if (board[row][col] != null) {
                    if (board[row][col].getType() == PieceType.BLACK) {
                        blackExists = true;
                        if (canMove(row, col)) {
                            blackCanMove = true; // Check if black pieces can move
                        }
                    } else if (board[row][col].getType() == PieceType.WHITE) {
                        whiteExists = true;
                        if (canMove(row, col)) {
                            whiteCanMove = true; // Check if white pieces can move
                        }
                    }
                }
            }
        }

        if (!blackExists || !blackCanMove) { // Check if white wins
            JOptionPane.showMessageDialog(this, "White wins!");
            BufferedReader reader = new BufferedReader(new FileReader("stats.txt"));
            int whiteWins = Integer.parseInt(reader.readLine());
            int blackWins = Integer.parseInt(reader.readLine());
            reader.close();
            FileWriter fw = new FileWriter("stats.txt"); // Creates a file writer object
            PrintWriter output = new PrintWriter(fw); // Creates a print writer object
            output.println(whiteWins + 1); // Increment white wins
            output.println(blackWins);
            output.close();
        } else if (!whiteExists || !whiteCanMove) { // Check if black wins
            JOptionPane.showMessageDialog(this, "Black wins!");
            BufferedReader reader = new BufferedReader(new FileReader("stats.txt"));
            int whiteWins = Integer.parseInt(reader.readLine());
            int blackWins = Integer.parseInt(reader.readLine());
            reader.close();
            FileWriter fw = new FileWriter("stats.txt"); // Creates a file writer object
            PrintWriter output = new PrintWriter(fw); // Creates a print writer object
            output.println(whiteWins);
            output.println(blackWins + 1); // Increment black wins
            output.close();
        } else if (!blackCanMove && !whiteCanMove) { // Check if it's a tie
            JOptionPane.showMessageDialog(this, "It's a tie!");
        }
    }

    /**
     * Method to check if a piece can move
     * @param row the row that the piece is in
     * @param col the column that the piece is in
     * @return true if the piece can move and false if not
     */
    private boolean canMove(int row, int col) {
        Piece piece = board[row][col]; // Get the piece to check
        if (piece == null) {
            return false;
        }

        int[] dRows = {-1, 1, -1, 1, -2, 2, -2, 2}; // Possible row differences for moves
        int[] dCols = {-1, -1, 1, 1, -2, -2, 2, 2}; // Possible column differences for moves

        for (int i = 0; i < 8; i++) {
            int newRow = row + dRows[i];
            int newCol = col + dCols[i];
            if (newRow >= 0 && newRow < BOARD_SIZE && newCol >= 0 && newCol < BOARD_SIZE) { // Check if the move is within bounds
                if (isValidMove(row, col, newRow, newCol)) {
                    return true; // The piece can move
                }
            }
        }
        return false; // The piece cannot move
    }

    /**
     * Method to update the frame title to show the current player's turn
     */
    private void updateTitle() {
        if (frame != null) {
            frame.setTitle(currentPlayer == PieceType.BLACK ? "Black's Turn" : "White's Turn");
        }
    }
}
/*
Algorithm:

Class Board extends JPanel implements ActionListener:
    Private Constants:
        BOARD_SIZE = 8
        Color light = Color.WHITE
        Color dark = Color.DARK_GRAY
        Color highlight = Color.YELLOW

    Private Variables:
        JButton[][] squares = new JButton[BOARD_SIZE][BOARD_SIZE]
        Piece[][] board = new Piece[BOARD_SIZE][BOARD_SIZE]
        int selectedRow = -1
        int selectedCol = -1
        PieceType currentPlayer = PieceType.BLACK
        boolean mustContinueCapture = false
        JFrame frame

    Constructor Board(JFrame frame):
        Set this.frame to frame
        Set layout to GridLayout with BOARD_SIZE rows and columns
        Call initializeBoard()
        Call setupBoard()
        Call updateTitle()

    Private Method initializeBoard():
        For each row from 0 to BOARD_SIZE-1:
            For each column from 0 to BOARD_SIZE-1:
                Create a new JButton button
                Set button preferred size to (80, 80)
                Add this instance as ActionListener to button
                Set button border painted to false
                Set button opaque to true
                Set button background color based on (row + col) % 2 (alternating light and dark colors)
                Assign button to squares[row][col]
                Add button to the panel

    Private Method setupBoard():
        For each row from 0 to 2:
            For each column from (row % 2 == 0 ? 1 : 0) to BOARD_SIZE-1 step 2:
                Place black pieces on the board

        For each row from 5 to 7:
            For each column from (row % 2 == 0 ? 1 : 0) to BOARD_SIZE-1 step 2:
                Place white pieces on the board

        Call refreshBoard()

    Private Method refreshBoard():
        For each row from 0 to BOARD_SIZE-1:
            For each column from 0 to BOARD_SIZE-1:
                If board[row][col] is null:
                    Set squares[row][col] icon to null
                Else:
                    Set the icon of squares[row][col] based on piece type and whether it is a king
                Reset the background color of squares[row][col]

    Override Method actionPerformed(ActionEvent e):
        Get the source button from the event
        For each row from 0 to BOARD_SIZE-1:
            For each column from 0 to BOARD_SIZE-1:
                If squares[row][col] equals the source button:
                    Try to call handleMove(row, col)
                    Catch IOException and throw RuntimeException

    Private Method handleMove(int row, int col) throws IOException:
        If no piece is selected (selectedRow == -1):
            If board[row][col] is not null and its type is currentPlayer:
                Select the piece at (row, col)
                Highlight the selected square
        Else:
            If the move from (selectedRow, selectedCol) to (row, col) is valid:
                Move the piece
                If the move is a capture (distance is 2):
                    Remove the captured piece
                Crown the piece if it reaches the opposite end
                Refresh the board

                If the move is a capture and the piece can capture more:
                    Continue capturing
                    Highlight the new position
                    Return

                Reset mustContinueCapture to false
                Check for win conditions
                Switch the current player
                Update the title
            If not continuing capture:
                Reset the background of the previously selected square
                Deselect the piece

    Private Method movePiece(int fromRow, int fromCol, int toRow, int toCol):
        Move the piece on the board

    Private Method crownPiece(int row, int col):
        If the piece reaches the opposite end, set it as a king

    Private Method isValidMove(int fromRow, int fromCol, int toRow, int toCol) returns boolean:
        Validate the move according to the rules of the game
        Return true if valid, else false

    Private Method canCaptureMore(int row, int col) returns boolean:
        Check if the piece at (row, col) can make further captures
        Return true if it can, else false

    Private Method checkForWin() throws IOException:
        Initialize flags for existence and move capability of both players
        For each row from 0 to BOARD_SIZE-1:
            For each column from 0 to BOARD_SIZE-1:
                If a piece exists, update the existence and move capability flags

        If black pieces do not exist or cannot move:
            Show message "White wins!"
            Update stats file
        Else if white pieces do not exist or cannot move:
            Show message "Black wins!"
            Update stats file
        Else if neither can move:
            Show message "It's a tie!"

    Private Method canMove(int row, int col) returns boolean:
        Check if the piece at (row, col) can make any valid moves
        Return true if it can, else false

    Private Method updateTitle():
        Update the frame title based on the current player
 */