__author__ = "Ben Newman"
"""
Date: January 20, 2023
Title: Galaga
Description: Creates a galaga game with a working menu, pausing, and achievements
"""

# Imports
import pygame
import time
from pygame import mixer

# Configuration
pygame.init()
# Creates the frame rate of the pygame window which is 60 FPS
fps = 60
fpsClock = pygame.time.Clock()
# Sets up the dimensions of the screen
screen_width, screen_height = 640, 480
# Creates the screen
screen = pygame.display.set_mode((screen_width, screen_height))
# Title of screen
pygame.display.set_caption("Galaga")
# Initializes the fonts
font1 = pygame.font.SysFont('neolatinademoffp', 40)
font2 = pygame.font.SysFont('neolatinademoffp', 30)
font3 = pygame.font.SysFont('neolatinademoffp', 20)
titleFont = pygame.font.SysFont('neolatinademoffp', 50)
# Initializes the volume of sounds
mixer.music.set_volume(1)
# Initializes player location
player_y = 350
player_x = 295
# Initializes player health
hit_points = 3
# Used to tell how many bullets exist currently
bullet_count = 0
# Increases when enemy is killed, is used to check when all enemies are defeated
score = 0
# Allows for the player time to react so that click spam does not occur
wait_count = 0
# Allows the explosion images to be cycled through when player dies
player_count = 0
# Checks if the space key has already been pressed so spam does not occur
space_pressed = False
# Checks if the player still has ammo
no_ammo = False
# Makes sure music does not spam over itself
music_playing = False
# Dictates whether the achievements have been obtained yet
easy_achievement = False
normal_achievement = False
hard_achievement = False
god_achievement = False
Button_Objects = []

# Sets RGB colour values to words
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREY = (127, 127, 127)
HOVER_GREY = (102, 102, 102)
CLICK_GREY = (51, 51, 51)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)
PURPLE = (255, 0, 255)
YELLOW = (255, 255, 0)
ORANGE = (255, 165, 0)
CYAN = (0, 255, 255)
INDIGO = (75, 0, 130)

# Is a list of bullets and their boolean values of whether they have been shot
shoot = []
# Is a list of all created buttons at a time
# Is the current scene the player is on
scene = "main_menu"


# Creating a Button
class Button:
    def __init__(self, x, y, width, height, buttonText='Button', onclickFunction=None, onePress=False, colour1=WHITE,
                 colour2=HOVER_GREY, colour3=CLICK_GREY):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.onclickFunction = onclickFunction
        self.onePress = onePress

        self.fillColors = {
            'normal': colour1,
            'hover': colour2,
            'pressed': colour3,
        }

        self.buttonSurface = pygame.Surface((self.width, self.height))
        self.buttonRect = pygame.Rect(self.x, self.y, self.width, self.height)

        self.buttonSurf = font1.render(buttonText, True, (20, 20, 20))

        self.alreadyPressed = False

        Button_Objects.append(self)

    def process(self):
        """
        Creates the button and detects for collision
        """

        mousePos = pygame.mouse.get_pos()

        self.buttonSurface.fill(self.fillColors['normal'])
        if self.buttonRect.collidepoint(mousePos):
            self.buttonSurface.fill(self.fillColors['hover'])

            if pygame.mouse.get_pressed(num_buttons=3)[0]:
                self.buttonSurface.fill(self.fillColors['pressed'])

                if self.onePress:
                    self.onclickFunction()

                elif not self.alreadyPressed:
                    self.onclickFunction()
                    self.alreadyPressed = True

            else:
                self.alreadyPressed = False

        self.buttonSurface.blit(self.buttonSurf, [
            self.buttonRect.width / 2 - self.buttonSurf.get_rect().width / 2,
            self.buttonRect.height / 2 - self.buttonSurf.get_rect().height / 2
        ])
        screen.blit(self.buttonSurface, self.buttonRect)


# Creates a Bullet for the Player to shoot
class Bullet:
    def __init__(self):
        # If the bullet tracks the player x
        self.follow = True
        # If the space key is already pressed
        self.spacePressed = False
        # If the bullet should move down
        self.move = False
        # The x coordinate of the bullet when space is pressed
        self.staticX = player_x + 22
        # The x coordinate of the bullet
        self.x = player_x + 22
        # The y coordinate of the bullet
        self.y = 350
        # If the bullet should be drawn
        self.gone = False

    def draw_bullet(self):
        if not self.gone:
            if self.follow:
                self.x = player_x + 22
            else:
                self.x = self.staticX

            if keys[pygame.K_SPACE] and not self.spacePressed:
                self.staticX = player_x + 22
                self.move = True
                self.follow = False
                self.spacePressed = True

            if self.move:
                self.y -= 15

            pygame.draw.rect(screen, BLUE, (self.x + 2, self.y, 2, 4))
            pygame.draw.rect(screen, BLUE, (self.x, self.y + 4, 6, 4))
            pygame.draw.rect(screen, RED, (self.x + 2, self.y + 8, 2, 10))


# Creates an enemy
class Enemy:
    def __init__(self, x, y):
        """
        Initiates Enemy attributes
        :param x: x coordinate of the enemy
        :param y: y coordinate of the enemy
        """
        self.x = x
        self.y = y
        # If the enemy exists
        self.disappear = False
        # If the enemy should commence explosion sequence
        self.destroyed = False
        # Used to draw bullet hit boxes
        self.count = 1
        self.dictionary = {}
        # Checks if the player bullet has hit the enemy
        self.collide = False

    def draw_enemy(self):
        global score
        explosion_img = pygame.transform.scale(pygame.image.load("Empty.png"), (35, 35))
        if not self.destroyed:
            enemy_img = pygame.transform.scale(pygame.image.load("Enemy.png"), (35, 35))
            enemy_hitbox = pygame.rect.Rect(self.x, self.y, 35, 35)

            screen.blit(enemy_img, (self.x, self.y))
            if self.disappear:
                self.destroyed = True
                mixer.music.load("Enemy_die.mp3")
                mixer.music.set_volume(1)
                mixer.music.play()
                score += 1

            for j in range(bullet_count):
                bullet_x = bullet_dictionary["bullet" + str(j + 1)]
                bullet_y = bullet_dictionary["bullet" + str(j + 1)]
                self.dictionary["bullet_hitbox{0}".format(j)] = pygame.rect.Rect(bullet_x.x, bullet_y.y, 6, 18)
                self.collide = pygame.Rect.colliderect(enemy_hitbox, self.dictionary["bullet_hitbox" + str(j)])
                if self.collide:
                    bullet_dictionary["bullet" + str(j + 1)].gone = True
                    self.disappear = True

        else:
            if self.count < 9:
                self.count += 0.2
                if self.count//1 == 1:
                    explosion_img = pygame.transform.scale(pygame.image.load("Stage_1.png"), (35, 35))
                elif self.count//1 == 2:
                    explosion_img = pygame.transform.scale(pygame.image.load("Stage_2.png"), (35, 35))
                elif self.count//1 == 3:
                    explosion_img = pygame.transform.scale(pygame.image.load("Stage_3.png"), (35, 35))
                elif self.count//1 == 4:
                    explosion_img = pygame.transform.scale(pygame.image.load("Stage_4.png"), (35, 35))
                elif self.count//1 == 5:
                    explosion_img = pygame.transform.scale(pygame.image.load("Stage_5.png"), (35, 35))
                elif self.count//1 == 6:
                    explosion_img = pygame.transform.scale(pygame.image.load("Stage_6.png"), (35, 35))
                elif self.count//1 == 7:
                    explosion_img = pygame.transform.scale(pygame.image.load("Stage_7.png"), (35, 35))
                elif self.count//1 == 8:
                    explosion_img = pygame.transform.scale(pygame.image.load("Stage_8.png"), (35, 35))
                if self.count > 8:
                    explosion_img = pygame.transform.scale(pygame.image.load("Empty.png"), (35, 35))
                screen.blit(explosion_img, (self.x, self.y))


# Creates Lasers for the enemies to shoot
class Laser:
    def __init__(self, enemy_number):
        """
        Initiates attributes of enemy bullets
        :param enemy_number: Number of enemies that currently exist
        """
        self.follow = True
        self.move = False
        self.staticX = player_x + 22
        self.x = enemy_dictionary["enemy" + str(enemy_number)].x
        self.y = enemy_dictionary["enemy" + str(enemy_number)].y
        self.enemy_number = enemy_number
        # If laser should be drawn
        self.gone = enemy_dictionary["enemy" + str(enemy_number)].destroyed
        self.draw = True
        # Used to draw hit boxes for the lasers
        self.dictionary = {}
        # Checks if the laser has hit the player
        self.collided = False

    def draw_laser(self, shoot_laser):
        """
        Main function of the Laser class
        :param shoot_laser: Whether the laser should move or not
        :return:
        """
        global hit_points
        player_hitbox = pygame.rect.Rect(player_x, player_y, 50, 50)
        collide = pygame.Rect.colliderect(pygame.rect.Rect(self.x, self.y, 6, 18), player_hitbox)

        if not self.gone:
            if not self.collided:
                if collide:
                    hit_points -= 1
                    mixer.music.load("Player_hit.mp3")
                    mixer.music.set_volume(0.5)
                    mixer.music.play()
                    self.collided = True
            else:
                self.draw = False

            if self.follow:
                self.x = enemy_dictionary["enemy" + str(self.enemy_number)].x + 15
                self.y = enemy_dictionary["enemy" + str(self.enemy_number)].y
            else:
                self.x = self.staticX

            if shoot_laser:
                self.staticX = enemy_dictionary["enemy" + str(self.enemy_number)].x + 15
                self.move = True
                self.follow = False

        if self.move:
            self.y += 5

        if self.draw:
            pygame.draw.rect(screen, RED, (self.x + 2, self.y + 14, 2, 4))
            pygame.draw.rect(screen, RED, (self.x, self.y + 10, 6, 4))
            pygame.draw.rect(screen, WHITE, (self.x + 2, self.y, 2, 10))

        if self.y > 480:
            shoot[self.enemy_number - 1] = False
            self.follow = True
            self.move = False
            self.gone = enemy_dictionary["enemy" + str(self.enemy_number)].destroyed
            self.collided = False
            if self.gone:
                self.draw = False
            else:
                self.draw = True


def movement():
    """
    Checks for user input of arrow keys for movement
    Global Variable- player_x
    """
    global player_x
    if (keys[pygame.K_LEFT] or keys[pygame.K_a]) and player_x > 0:
        player_x -= 5
    if (keys[pygame.K_RIGHT] or keys[pygame.K_d]) and player_x + 50 < screen_width:
        player_x += 5


def healthbar():
    """
    Creates the healthbar at the bottom of the screen based on health of player
    """
    pygame.draw.rect(screen, GREEN, (0, 460, 70 * hit_points, 20))
    pygame.draw.rect(screen, WHITE, (0, 460, 210, 20), 2)
    text_add(font2, WHITE, 18, 425, "Ship Health")


def draw_player(x, y):
    """
    Draws the player sprite
    :param x: x coordinate of the player
    :param y: y coordinate of the player
    Global Variables- hit_points, scene, player_count
    """
    global hit_points
    global scene
    global player_count
    explosion_img = pygame.transform.scale(pygame.image.load("Empty.png"), (50, 50))
    if hit_points > 0:
        explosion_img = pygame.transform.scale(pygame.image.load("Player.png"), (50, 50))
    else:
        if player_count < 9:
            player_count += 0.2
            if player_count == 0.2:
                mixer.music.load("explosion.mp3")
                mixer.music.set_volume(1)
                mixer.music.play()
            if player_count // 1 == 1:
                explosion_img = pygame.transform.scale(pygame.image.load("Stage_1.png"), (50, 50))
            elif player_count // 1 == 2:
                explosion_img = pygame.transform.scale(pygame.image.load("Stage_2.png"), (50, 50))
            elif player_count // 1 == 3:
                explosion_img = pygame.transform.scale(pygame.image.load("Stage_3.png"), (50, 50))
            elif player_count // 1 == 4:
                explosion_img = pygame.transform.scale(pygame.image.load("Stage_4.png"), (50, 50))
            elif player_count // 1 == 5:
                explosion_img = pygame.transform.scale(pygame.image.load("Stage_5.png"), (50, 50))
            elif player_count // 1 == 6:
                explosion_img = pygame.transform.scale(pygame.image.load("Stage_6.png"), (50, 50))
            elif player_count // 1 == 7:
                explosion_img = pygame.transform.scale(pygame.image.load("Stage_7.png"), (50, 50))
            elif player_count // 1 == 8:
                explosion_img = pygame.transform.scale(pygame.image.load("Stage_8.png"), (50, 50))
            if player_count > 8:
                explosion_img = pygame.transform.scale(pygame.image.load("Empty.png"), (50, 50))
                scene = "easy_3"
    screen.blit(explosion_img, (x, y))


def text_add(font_style, colour, x, y, text):
    """
    Simplifies the text creation and blit process
    :param font_style: font style and size for the text
    :param colour: colour of the text
    :param x: x coordinate of the text
    :param y: y coordinate of the text
    :param text: text that is being blit
    """
    txt = font_style.render(text, True, colour)
    screen.blit(txt, (x, y))


def click_sound():
    """
    Makes a click sound
    """
    mixer.music.load("Click.mp3")
    mixer.music.set_volume(1)
    mixer.music.play()


def main_menu():
    """
    Takes user to the main menu
    Global Variable - scene
    """
    global scene
    click_sound()
    scene = "main_menu"


def main_menu_pause():
    """
    Takes user to main menu but pauses so the user doesn't click on another button
    Global Variable - scene
    """
    global scene
    click_sound()
    scene = "main_menu"
    time.sleep(0.2)


def level_select():
    """
    Takes the user to the level select menu
    Global Variable - Scene
    """
    global scene
    click_sound()
    scene = "level_menu"


def controls_menu():
    """
    Takes user to the control menu
    Global Variable - scene
    """
    global scene
    click_sound()
    scene = "controls_menu"


def achievements_menu():
    """
    Takes user to the achievement menu
    Global Variable - scene
    """
    global scene
    click_sound()
    scene = "achievements_menu"


def pause_menu():
    """
    Pauses the game
    Global Variable - Scene
    """
    global scene
    scene = "pause_menu"


def easy_mode():
    """
    Starts the easy level of the game
    Global Variable - scene
    """
    global scene
    click_sound()
    scene = "easy_1"


def normal_mode():
    """
    Starts the normal level of the game
    Global Variable - scene
    """
    global scene
    click_sound()
    scene = "normal_1"


def hard_mode():
    """
    Starts the hard level of the game
    Global Variable - scene
    """
    global scene
    click_sound()
    scene = "hard_1"


def resume_level():
    """
    Takes the user back to the level they paused
    Global Variable - scene
    """
    global scene
    scene = go_back_to


# Initiates buttons
levelSelect = Button(170, 170, 300, 50, 'Level Select', level_select, False)
controlsMenu = Button(170, 250, 300, 50, 'Controls', controls_menu, False)
achievementsMenu = Button(170, 330, 300, 50, 'Achievements', achievements_menu, False)
mainMenuHigh = Button(170, 170, 300, 50, 'Main Menu', main_menu_pause, False)
mainMenuLow = Button(170, 250, 300, 50, 'Main Menu', main_menu_pause, False)
backButton = Button(0, 0, 100, 50, 'Back', main_menu, False)
easyMode = Button(170, 220, 300, 50, 'Easy', easy_mode, False, CYAN)
normalMode = Button(170, 290, 300, 50, 'Normal', normal_mode, False, ORANGE)
hardMode = Button(170, 360, 300, 50, 'Hard', hard_mode, False, RED)
resume = Button(170, 170, 300, 50, 'Resume', resume_level, False)


# Initiates enemies and lasers
enemy_dictionary = {}
laser_dictionary = {}
for i in range(29):
    if i < 10:
        enemy_dictionary["enemy{0}".format(i)] = Enemy(i * 60, 10)
    elif i < 20:
        enemy_dictionary["enemy{0}".format(i)] = Enemy((i-9) * 60 - 30, 60)
    else:
        enemy_dictionary["enemy{0}".format(i)] = Enemy((i-19) * 60, 120)
    laser_dictionary["laser{0}".format(i)] = Laser(i)
    shoot.append(False)

# Initiates bullets
bullet_dictionary = {}
for i in range(10000):
    bullet_dictionary["bullet{0}".format(i)] = Bullet()


# Main game loop
while True:
    # Makes it easier to call function
    keys = pygame.key.get_pressed()
    # So that background is still visible during certain scenes
    if scene != "pause_menu" and scene != "easy_2" and scene != "easy_3":
        screen.fill(BLACK)

    # Main Menu
    if scene == "main_menu":
        text_add(titleFont, GREEN, 215, 40, "GALAGA")
        text_add(font3, WHITE, 0, 460, "Made by: Ben Newman")

        levelSelect.process()
        controlsMenu.process()
        achievementsMenu.process()

    # Level Menu
    if scene == "level_menu":
        enemy_dictionary = {}
        laser_dictionary = {}
        for i in range(29):
            if i < 10:
                enemy_dictionary["enemy{0}".format(i)] = Enemy(i * 60, 10)
            elif i < 20:
                enemy_dictionary["enemy{0}".format(i)] = Enemy((i - 9) * 60 - 30, 60)
            else:
                enemy_dictionary["enemy{0}".format(i)] = Enemy((i - 19) * 60, 120)

            laser_dictionary["laser{0}".format(i)] = Laser(i)

        bullet_dictionary = {}
        for i in range(10000):
            bullet_dictionary["bullet{0}".format(i)] = Bullet()

        hit_points = 3
        no_ammo = False
        bullet_count = 0
        score = 0
        wait_count = 0
        player_count = 0
        music_playing = False
        for i in shoot:
            shoot[i] = False
        player_x = 295

        text_add(titleFont, GREEN, 170, 100, "Level Select")

        backButton.process()
        easyMode.process()
        normalMode.process()
        hardMode.process()

    # Control Menu
    if scene == "controls_menu":
        text_add(titleFont, GREEN, 200, 100, "Controls")
        text_add(font2, CYAN, 150, 200, "Press 'Space' to shoot")
        text_add(font2, CYAN, 100, 275, "Use the arrow keys to move")
        text_add(font2, CYAN, 90, 350, "Press 'esc' to pause the game")

        backButton.process()

    # Achievement Menu
    if scene == "achievements_menu":
        backButton.process()
        if easy_achievement:
            easy_img = pygame.transform.scale(pygame.image.load("easy.jpeg"), (75, 75))
        else:
            easy_img = pygame.transform.scale(pygame.image.load("easyBW.jpg"), (75, 75))
        screen.blit(easy_img, (120, 75))
        if normal_achievement:
            normal_img = pygame.transform.scale(pygame.image.load("normal.jpg"), (75, 75))
        else:
            normal_img = pygame.transform.scale(pygame.image.load("normalBW.jpg"), (75, 75))
        screen.blit(normal_img, (120, 175))
        if hard_achievement:
            hard_img = pygame.transform.scale(pygame.image.load("hard.jpeg"), (75, 75))
        else:
            hard_img = pygame.transform.scale(pygame.image.load("hardBW.jpg"), (75, 75))
        screen.blit(hard_img, (120, 275))
        if god_achievement:
            god_img = pygame.transform.scale(pygame.image.load("god.jpeg"), (75, 75))
        else:
            god_img = pygame.transform.scale(pygame.image.load("question.jpg"), (75, 75))
        screen.blit(god_img, (120, 375))
        text_add(font1, CYAN, 210, 70, "Complete the")
        text_add(font1, CYAN, 210, 110, "Easy Level")
        text_add(font1, CYAN, 210, 170, "Complete the")
        text_add(font1, CYAN, 210, 210, "Normal Level")
        text_add(font1, CYAN, 210, 270, "Complete the")
        text_add(font1, CYAN, 210, 310, "Hard Level")
        if god_achievement:
            text_add(font1, CYAN, 210, 370, "Complete the Hard")
            text_add(font1, CYAN, 210, 410, "Level With Full Health")
        else:
            text_add(font1, CYAN, 210, 395, "???")

    # When game is paused
    if scene == "pause_menu":
        resume.process()
        mainMenuLow.process()

    # Easy Level
    if scene == "easy_1":
        if keys[pygame.K_ESCAPE]:
            go_back_to = "easy_1"
            scene = "pause_menu"

        movement()

        for i in range(9):
            laser_dictionary["laser" + str(i + 1)].draw_laser(shoot[i])
            enemy_dictionary["enemy" + str(i + 1)].draw_enemy()
            if enemy_dictionary["enemy" + str(i + 1)].x - 25 < player_x < enemy_dictionary["enemy" + str(i + 1)].x + 60:
                shoot[i] = True

        for i in range(bullet_count):
            bullet_dictionary["bullet" + str(i + 1)].draw_bullet()

        if keys[pygame.K_SPACE]:
            if not space_pressed:
                bullet_count += 1
                if not no_ammo:
                    mixer.music.load("Laser.mp3")
                    mixer.music.set_volume(0.5)
                    mixer.music.play()
                space_pressed = True
        else:
            space_pressed = False
        if bullet_count == 9999:
            print("Somehow you used ten thousand bullets which means you have no more ammo.")
            no_ammo = True
            bullet_count = 0
        if no_ammo:
            text_add(font2, RED, 245, 200, "NO AMMO")

        draw_player(player_x, player_y)
        healthbar()

        if score >= 9:
            wait_count += 1
            if wait_count >= 15:
                scene = "easy_2"
                easy_achievement = True

    # Easy Win Screen
    if scene == "easy_2":
        if not music_playing:
            mixer.music.load("Yay.mp3")
            mixer.music.set_volume(1)
            mixer.music.play()
            music_playing = True
        text_add(titleFont, GREEN, 110, 40, "EASY COMPLETE!")
        mainMenuHigh.process()

    # Level Fail Screen
    if scene == "easy_3":
        text_add(titleFont, RED, 150, 100, "LEVEL FAILED")
        mainMenuLow.process()

    # Normal Level
    if scene == "normal_1":
        if keys[pygame.K_ESCAPE]:
            go_back_to = "normal_1"
            scene = "pause_menu"

        movement()

        for i in range(19):
            laser_dictionary["laser" + str(i + 1)].draw_laser(shoot[i])
            enemy_dictionary["enemy" + str(i + 1)].draw_enemy()
            if enemy_dictionary["enemy" + str(i + 1)].x - 25 < player_x < enemy_dictionary["enemy" + str(i + 1)].x + 60:
                shoot[i] = True

        for i in range(bullet_count):
            bullet_dictionary["bullet" + str(i + 1)].draw_bullet()

        if keys[pygame.K_SPACE]:
            if not space_pressed:
                bullet_count += 1
                if not no_ammo:
                    mixer.music.load("Laser.mp3")
                    mixer.music.set_volume(0.5)
                    mixer.music.play()
                space_pressed = True
        else:
            space_pressed = False
        if bullet_count == 9999:
            print("Somehow you used ten thousand bullets which means you have no more ammo.")
            no_ammo = True
            bullet_count = 0
        if no_ammo:
            text_add(font2, RED, 245, 200, "NO AMMO")

        draw_player(player_x, player_y)
        healthbar()

        if score >= 19:
            wait_count += 1
            if wait_count >= 15:
                scene = "normal_2"
                normal_achievement = True

    # Normal Win Screen
    if scene == "normal_2":
        if not music_playing:
            mixer.music.load("Yay.mp3")
            mixer.music.set_volume(1)
            mixer.music.play()
            music_playing = True
        text_add(titleFont, GREEN, 70, 40, "NORMAL COMPLETE!")
        mainMenuHigh.process()

    # Hard Level
    if scene == "hard_1":
        if keys[pygame.K_ESCAPE]:
            go_back_to = "hard_1"
            scene = "pause_menu"

        movement()

        for i in range(28):
            laser_dictionary["laser" + str(i + 1)].draw_laser(shoot[i])
            enemy_dictionary["enemy" + str(i + 1)].draw_enemy()
            if enemy_dictionary["enemy" + str(i + 1)].x - 25 < player_x < enemy_dictionary["enemy" + str(i + 1)].x + 60:
                shoot[i] = True

        for i in range(bullet_count):
            bullet_dictionary["bullet" + str(i + 1)].draw_bullet()

        if keys[pygame.K_SPACE]:
            if not space_pressed:
                bullet_count += 1
                if not no_ammo:
                    mixer.music.load("Laser.mp3")
                    mixer.music.set_volume(0.5)
                    mixer.music.play()
                space_pressed = True
        else:
            space_pressed = False
        if bullet_count == 9999:
            print("Somehow you used ten thousand bullets which means you have no more ammo.")
            no_ammo = True
            bullet_count = 0
        if no_ammo:
            text_add(font2, RED, 245, 200, "NO AMMO")

        draw_player(player_x, player_y)
        healthbar()

        if score >= 28:
            wait_count += 1
            if wait_count >= 15:
                scene = "hard_2"
                if hit_points == 3:
                    god_achievement = True
                hard_achievement = True

    # Hard Win Screen
    if scene == "hard_2":
        if not music_playing:
            mixer.music.load("Yay.mp3")
            mixer.music.set_volume(1)
            mixer.music.play()
            music_playing = True
        text_add(titleFont, GREEN, 110, 40, "HARD COMPLETE!")
        mainMenuHigh.process()

    # Refreshes Screen
    pygame.display.flip()
    # Maintains FPS
    fpsClock.tick(fps)

    # Checks if the pygame window has been closed
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
